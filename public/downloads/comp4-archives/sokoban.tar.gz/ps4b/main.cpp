// Copyright 2023 Leonard Nguyen
#include <iostream>
#include <fstream>
#include <sstream>

#include "Sokoban.hpp"

int main() {
    sf::Clock clock;
    sf::Time t, bestTime;

    sf::Font font;
    if (!font.loadFromFile("./src/NiseJSRF.ttf")) {} else {}
    sf::Text winMessage;
    winMessage.setFont(font);
    winMessage.setCharacterSize(32);
    winMessage.setFillColor(sf::Color::Red);
    winMessage.setStyle(sf::Text::Bold);

    Sokoban game;
    std::cin >> game;
    std::cout << game << std::endl;

    const unsigned int windowSizeX = game.width();
    const unsigned int windowSizeY = game.height();
    sf::RenderWindow window(sf::VideoMode(windowSizeX*Sokoban::TILE_SIZE,
    windowSizeY*Sokoban::TILE_SIZE), "SFML works!");

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
            } else if (event.type == sf::Event::KeyPressed) {
                // restart key
                switch (event.key.code) {
                    case sf::Keyboard::R:   // restart
                        window.clear();
                        game.restartGame();
                        clock.restart();
                        break;

                    default: break;
                }

                // control player
                if (!game.isWon()) {
                    t = clock.getElapsedTime();
                    switch (event.key.code) {
                        case sf::Keyboard::W:   // Up
                            game.movePlayer(Up);
                            break;
                        case sf::Keyboard::Up:  // Up
                            game.movePlayer(Up);
                            break;

                        case sf::Keyboard::S:   // Down
                            game.movePlayer(Down);
                            break;
                        case sf::Keyboard::Down:    // Down
                            game.movePlayer(Down);
                            break;

                        case sf::Keyboard::A:   // Left
                            game.movePlayer(Left);
                            break;
                        case sf::Keyboard::Left:    // Left
                            game.movePlayer(Left);
                            break;

                        case sf::Keyboard::D:   // Right
                            game.movePlayer(Right);
                            break;

                        case sf::Keyboard::Right:   // Right
                            game.movePlayer(Right);
                            break;

                        default: break;
                    }
                }
            }
        }

        window.clear();
        window.draw(game);
        if (game.isWon()) {
            std::stringstream winString;
            winString << "Won in " << t.asSeconds() << "secs" << std::endl
            << "Press R to Play again.";
            winMessage.setString(winString.str());
            window.draw(winMessage);
        }
        window.display();
    }

    return 0;
}
