# PS2a: Sokoban

## Contact
Name: Leonard Nguyen
Section: Summer 011
Time to Complete: a few days


## Description
This project is an SFML implementation of Sokoban, a Japanese tile based game where
you play as a warehouse keeper that pushes boxes around into their proper locations
found on the map. There're a ton of implementations of this sort of game done in
many different ways. This particular project is done with SFML and its development
is split into parts A and B.

Part B was setting up the main gameplay. Here, the main gameplay is to get the boxes into
their drop off locations. The player gets a win message when the game is completed. The
movement rules are that both the player and boxes cannot move through other objects. This
includes walls and other boxes.

### Features
For this project, we were tasked to make a Sokoban class to hold everything that the
game itself would need. We were given functions to implement and were suggested some
fields to represent each of the data stored into Sokoban.

Aside from the memory storage, the project holds the size of the map (width and height),
the textures for each tile possible in a game, and the indexes of the player, box, and
box drop-off location.

The functions given to us to implement are movePlayer(Direction dir) and isWon().

The movePlayer function handles pretty much all the conditions needed for the player to
move according to the rules of Sokoban. Both the boxes and the player share the same rule
for walls, which is just neither can pass through walls or the play area bounds. The boxes
however have an additional rule of which they cannot move when another box is blocking its
path. The code below represents an entity's target position as well as the position beyond
that target position:

    sf::Vector2i targetPos = _playerLocation + moveDir;     // moveDir depends on key pressed
    sf::Vector2i beyondBoxPos = targetPos + moveDir;

The enumerated directions were encoded to the wasd and arrow keys using the event.key.code
from the SFML library. Each key pressed sends a direction Up, Down, Left, or Right to the
movePlayer(dir) function. This allows the function to update the player location according
to what key is pressed.

The key event cases (including 'R' key to restart game) in main are as follows:

    // restart key
    switch (event.key.code) {
        case sf::Keyboard::R:   // restart
            window.clear();
            game.restartGame();
            clock.restart();
            break;

            default: break;
    }

    // control player
    if (!game.isWon()) {
        t = clock.getElapsedTime();
        switch (event.key.code) {
            case sf::Keyboard::W:   // Up
                game.movePlayer(Up);
                break;
            case sf::Keyboard::Up:  // Up
                game.movePlayer(Up);
                break;

            case sf::Keyboard::S:   // Down
                game.movePlayer(Down);
                break;
            case sf::Keyboard::Down:    // Down
                game.movePlayer(Down);
                break;

            case sf::Keyboard::A:   // Left
                game.movePlayer(Left);
                break;
            case sf::Keyboard::Left:    // Left
                game.movePlayer(Left);
                break;

            case sf::Keyboard::D:   // Right
                game.movePlayer(Right);
                break;

            case sf::Keyboard::Right:   // Right
                game.movePlayer(Right);
                break;

            default: break;
        }
    }

Which is fed to the switch case that controls the player's movement direction:

    switch (dir) {
        case Up:
            _facing = Up;
            moveDir = {0, -1};
            break;
        case Down:
            _facing = Down;
            moveDir = {0, 1};
            break;
        case Left:
            _facing = Left;
            moveDir = {-1, 0};
            break;
        case Right:
            _facing = Right;
            moveDir = {1, 0};
            break;
        default:
            throw std::invalid_argument("Unknown enum");
    }

And these are the assignments that do the movement:

    *box = beyondBoxPos;        // dereferenced box iterator from "find_if" function
    _playerLocation = targetPos;

Rules for box movement are put separately from player movement. These are put under this
condition:

    auto box = std::find_if(_boxLocations.begin(), _boxLocations.end(),
    [targetPos](const sf::Vector2i &pos){return pos == targetPos;});

    if (box != _boxLocations.end())

The isWon function iterates through two vectors, one for each "box location" and the other
for each "box drop-off location". The function then compares any of the box locations with
any of the box drop-off locations. If they equal, it can be said that a box is in the same
location as in the drop-off location. When this happens, a counter goes up. When the counter
hits a number larger than the number of boxes or drop-offs, then the game is won. Of course,
there is a default condition for when there aren't any drop-offs, hence automatically
winning the game.

Since the Sokoban class is drawable, the draw function was utilized to draw the map in
row major. This is done by looping through the one dimensional array and using the index
formula i = x+y*w. The other entities like boxes and the player are drawn separately
according to their positions recorded from the istream operation overload.

### Memory
Since the game state is represented by a bunch of characters, I figured it'd be easiest to
just store all those characters into a single, one dimensional vector. The istream operator
loops across all the characters fed in by the lvl file and pushes each character into the
_tiles vector in row major order.

A vector of "box locations" as well as a vector of "box drop-off locations" were used since
there're multiple instances of each. Although these store integer vectors representing
position, the box locations could be treated as boxes for the purposes of movement rules.

### Lambdas
The isWon could be using a lambda in a find algorithm function to maybe capture a count for
how many locations are filled. The movePlayer function uses a find_if function that
initializes a "box" to be used to set off the condition for if there's a box in a
"target position".

    auto box = std::find_if(_boxLocations.begin(), _boxLocations.end(),
    [targetPos](const sf::Vector2i &pos){return pos == targetPos;});

### Issues
Collisions for 3 boxes or more are faulty. Can't get a condition that compares each box
individually. This results in box locations that're not adjacent to each other to ignore
collision. For example, box 1 and 2, 2 and 3, but not 1 and 3. Prefer to have a condition
that handles all the boxes evenly. The code in question:

    if (beyondBoxPos == *(box-1) || beyondBoxPos == *(box+1))

### Extra Credit
An attempt was made to get the player facing in different directions. Resulted in too many
leaks. The game tracks the time the player takes to complete a level and displays that as
the win message.


## Acknowledgements
<https://kenney.nl/assets/sokoban>
Dr. James Daly, University of Massachusetts Lowell
