// Copyright 2023 Leonard Nguyen
#include "Sokoban.hpp"

Sokoban::Sokoban() {
    _emptySpaceTexture.loadFromFile("./src/ground_01.png");
    _wallTexture.loadFromFile("./src/block_06.png");

    /*
    _playerTextures.resize(4);
    _playerTextures[Up].loadFromFile("./src/player_08.png");
    _playerTextures[Down].loadFromFile("./src/player_05.png");
    _playerTextures[Left].loadFromFile("./src/player_20.png");
    _playerTextures[Right].loadFromFile("./src/player_17.png");
    */

    _playerTexture.loadFromFile("./src/player_05.png");
    _boxTexture.loadFromFile("./src/crate_03.png");
    _boxDropOffTexture.loadFromFile("./src/ground_04.png");
}

std::istream &operator>>(std::istream &in, Sokoban &sokoban) {
    // std::vector<char> inputLevelLine;
    in >> sokoban._height >> sokoban._width;
    for (int i = 0; i < sokoban._width*sokoban._height; i++) {
        char inputLevelChar;
        in >> inputLevelChar;
        if (inputLevelChar == '@') {
            sokoban._playerLocation.x = i%sokoban._width;
            sokoban._playerLocation.y = i/sokoban._width;
        } else if (inputLevelChar == 'A') {
            sf::Vector2i boxCoords;
            boxCoords.x = i%sokoban._width;
            boxCoords.y = i/sokoban._width;
            sokoban._boxLocations.push_back(boxCoords);
        } else if (inputLevelChar == 'a') {
            sf::Vector2i boxDropOffCoords;
            boxDropOffCoords.x = i%sokoban._width;
            boxDropOffCoords.y = i/sokoban._width;
            sokoban._boxDropOffLocations.push_back(boxDropOffCoords);
        }
        sokoban._tiles.push_back(inputLevelChar);
    }
    return in;
}

std::ostream &operator<<(std::ostream &out, Sokoban &sokoban) {
    out << "Width: " << sokoban._width << std::endl;
    out << "Height: " << sokoban._height << std::endl;
    out << "Level Stream: ";
    for (auto i : sokoban._tiles) {
        out << i;
    }
    out << std::endl<< "Player Location: ("
    << sokoban._playerLocation.x << ", " << sokoban._playerLocation.y
    << ")";
    return out;
}

void Sokoban::movePlayer(Direction dir) {
    sf::Vector2i moveDir;
    switch (dir) {
        case Up:
            _facing = Up;
            moveDir = {0, -1};
            break;
        case Down:
            _facing = Down;
            moveDir = {0, 1};
            break;
        case Left:
            _facing = Left;
            moveDir = {-1, 0};
            break;
        case Right:
            _facing = Right;
            moveDir = {1, 0};
            break;
        default:
            throw std::invalid_argument("Unknown enum");
    }
    sf::Vector2i targetPos = _playerLocation + moveDir;
    if (targetPos.y < 0 || targetPos.x < 0 || targetPos.y >= _height || targetPos.x >= _width) {
        return;
    }
    char targetSymbol = _tiles.at(targetPos.y * _width + targetPos.x);
    if (targetSymbol == '#') {
        return;
    }
    // box movement
    auto box = std::find_if(_boxLocations.begin(), _boxLocations.end(),
    [targetPos](const sf::Vector2i &pos){return pos == targetPos;});
    if (box != _boxLocations.end()) {
        sf::Vector2i beyondBoxPos = targetPos + moveDir;
        if (beyondBoxPos.y < 0 || beyondBoxPos.x < 0 ||
        beyondBoxPos.y >= _height || beyondBoxPos.x >= _width) {
            return;
        }
        if (_tiles.at(beyondBoxPos.y * _width + beyondBoxPos.x) == '#') {
            return;
        }
        if (beyondBoxPos == *(box-1) || beyondBoxPos == *(box+1)) {     // fix this
            return;
        }
        *box = beyondBoxPos;
    }
    _playerLocation = targetPos;
}

void Sokoban::restartGame() {
    _boxLocations.clear();
    for (int i = 0; i < _width*_height; i++) {
        if (_tiles[i] == '@') {
            _playerLocation.x = i%_width;
            _playerLocation.y = i/_width;
        } else if (_tiles[i] == 'A') {
            sf::Vector2i boxCoords;
            boxCoords.x = i%_width;
            boxCoords.y = i/_width;
            _boxLocations.push_back(boxCoords);
        }
    }
}

bool Sokoban::isWon() const {
    size_t count = 0;
    // auto box = std::find_if(_boxLocations.begin(), _boxLocations.end(), []());

    for (auto box : _boxLocations) {
        for (auto dropOff : _boxDropOffLocations) {
            if (box == dropOff) {
                count++;
                if (count >= _boxLocations.size()) {
                    return true;
                } else if (count >= _boxDropOffLocations.size()) {
                    return true;
                }
            }
        }
    }
    return _boxDropOffLocations.empty();    // returns false unless no dropoff locs
}

void Sokoban::draw(sf::RenderTarget& target, sf::RenderStates states) const {
    sf::Sprite overworldSprite;
    for (int i = 0; i < _height; i++) {
        for (int j = 0; j < _width; j++) {
            if (_tiles.at(i* _width +j) == '#') {   // wall
                overworldSprite.setTexture(_wallTexture);
            } else if ((_tiles.at(i* _width +j) == '.') ||
            (_tiles.at(i* _width +j) == '@') ||
            (_tiles.at(i* _width +j) == 'A')) {      // ground
                overworldSprite.setTexture(_emptySpaceTexture);
            } else if (_tiles.at(i * _width + j) == 'a') {      // box drop-off
                overworldSprite.setTexture(_boxDropOffTexture);
            }
            overworldSprite.setPosition(j * TILE_SIZE,  i * TILE_SIZE);
            target.draw(overworldSprite);
        }
    }

    sf::Sprite boxSprite;
    boxSprite.setTexture(_boxTexture);
    for (auto & boxCoord : _boxLocations) {
        boxSprite.setPosition(boxCoord.x*TILE_SIZE, boxCoord.y*TILE_SIZE);
        target.draw(boxSprite);
    }

    sf::Sprite playerSprite;
    playerSprite.setTexture(_playerTexture);
    playerSprite.setPosition(_playerLocation.x * TILE_SIZE, _playerLocation.y * TILE_SIZE);
    target.draw(playerSprite);
}
