// Copyright 2023 Leonard Nguyen
#pragma once

#include <iostream>
#include <vector>
#include <memory>
#include <algorithm>
#include <SFML/Graphics.hpp>

enum Direction {Up, Down, Left, Right};

class Sokoban: public sf::Drawable {
 public:
    static const int TILE_SIZE = 64;

    // constructor(s)
    Sokoban();
    Sokoban(int height, int width);

    friend std::istream &operator>>(std::istream &in, Sokoban &sokoban);
    friend std::ostream &operator<<(std::ostream &out, Sokoban &sokoban);

    void movePlayer(Direction dir);
    bool isWon() const;
    void restartGame();

    int width() {return _width;}
    int height() {return _height;}

 private:
    int _height, _width;
    std::vector<char> _tiles;

    sf::Vector2i _playerLocation;
    std::vector<sf::Vector2i> _boxLocations;
    std::vector<sf::Vector2i> _boxDropOffLocations;

    Direction _facing;
    // std::vector<sf::Texture> _playerTextures;
    sf::Texture _playerTexture;
    sf::Texture _emptySpaceTexture;
    sf::Texture _wallTexture;
    sf::Texture _boxTexture;
    sf::Texture _boxDropOffTexture;
    sf::Texture _inLocationTexture;
    virtual void draw(sf::RenderTarget& target, sf::RenderStates states) const;
};
