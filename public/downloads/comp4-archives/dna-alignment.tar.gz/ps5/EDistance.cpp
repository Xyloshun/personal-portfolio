// Copyright 2023 Leonard Nguyen
#include <sstream>
#include "EDistance.hpp"

EDistance::EDistance(std::string input1, std::string input2) {
    _rowString = input1;
    _columnString = input2;
    std::vector<int> columnInput;

    // column allocation
    for (int i = 0; i < static_cast<int>(_columnString.length())+1; i++) {
        columnInput.push_back(0);
    }
    for (int j = 0; j < static_cast<int>(_rowString.length())+1; j++) {
        matrix.push_back(columnInput);
    }
}

int EDistance::penalty(char a, char b) {
    if (a == b) {
        return 0;
    } else {
        return 1;
    }
}

// basic minimum of 3 ints function
int EDistance::min3(int a, int b, int c) {
    int min;
    if (a < b) {
        min = a;
        if (c < min) {
            min = c;
            return min;
        } else {
            return min;
        }
    } else {
        min = b;
        if (c < min) {
            min = c;
            return min;
        } else {
            return min;
        }
    }
}

int EDistance::optDistance() {
    for (int i = matrix.size()-1; i >= 0; i--) {
        for (int j = matrix[i].size()-1; j >= 0; j--) {
            if ((i == static_cast<int>(matrix.size())-1) &&
            (j == static_cast<int>(matrix[i].size())-1)) {
                matrix[i][j] = 0;
            } else if (i == static_cast<int>(matrix.size())-1) {
                matrix[i][j] = matrix[i][j+1] + 2;
            } else if (j == static_cast<int>(matrix[i].size())-1) {
                matrix[i][j] = matrix[i+1][j] + 2;
            } else {
                matrix[i][j] = min3(matrix[i+1][j+1] + penalty(_rowString[i], _columnString[j]),
                matrix[i+1][j] + 2, matrix[i][j+1] + 2);
            }
        }
    }
    return matrix[0][0];
}

std::string EDistance::alignment() {
    int i = 0;
    int j = 0;
    std::stringstream alignedSequence;

    while ((i < static_cast<int>(matrix.size())-1) || (j < static_cast<int>(matrix[0].size())-1)) {
        if ((i < static_cast<int>(matrix.size())-1) &&
        (j < static_cast<int>(matrix[0].size())-1) &&
        (matrix[i+1][j+1] <= matrix[i+1][j]+1) &&
        (matrix[i+1][j+1]+1 <= matrix[i][j+1]+1)) {
            alignedSequence << _rowString[i] << " "
            << _columnString[j] << " "
            << matrix[i][j] - matrix[i+1][j+1]
            << std::endl;
            i++;
            j++;
        } else if (((i < static_cast<int>(matrix.size())-1) &&
        (matrix[i+1][j] <= matrix[i][j+1])) ||
        (j == static_cast<int>(matrix.size())-1)) {
            alignedSequence << _rowString[i] << " "<< "-" << " "
            << matrix[i][j] - matrix[i+1][j]
            << std::endl;
            i++;
        } else {
            alignedSequence << "-" << " "
            << _columnString << " "
            << matrix[i][j] - matrix[i][j+1]
            << std::endl;
            j++;
        }
    }

    return alignedSequence.str();
}
