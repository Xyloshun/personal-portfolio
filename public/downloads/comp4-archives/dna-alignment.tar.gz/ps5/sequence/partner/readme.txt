/**********************************************************************
 *  abbreviated partner readme template                                                   
 *  DNA Sequence Alignment
 **********************************************************************/

Name:
Login:
Precept:

Partner's name:
Partner's login:
Partner's precept:

Which partner is submitting the program files?

Please enter any additional comments in your main readme.txt file.
