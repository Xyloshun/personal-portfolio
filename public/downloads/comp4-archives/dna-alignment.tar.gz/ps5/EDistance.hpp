// Copyright 2023 Leonard Nguyen
#pragma once

#include <iostream>
#include <string>
#include <vector>

class EDistance {
 public:
    // constructor
    EDistance(std::string input1, std::string input2);

    static int penalty(char a, char b);
    static int min3(int a, int b, int c);

    int optDistance();          // return optimal distance
    std::string alignment();    // return alignment

 private:
    std::vector<std::vector<int>> matrix;
    std::string _rowString;
    std::string _columnString;
};
