# PS5: DNA Alignment

## Contact
Name: Leonard Nguyen
Section: Summer 110
Time to Complete: 12-15 hours

Partner:

## Description
The project is to develop a DNA Sequence Aligner program. Basically, it's a
program that takes two sequences of characters and then edits the distances
in a way that allows for the most optimal "alignment" between the two sequences.
Despite it being named a "DNA Sequence Aligner", the program doesn't necessarily
have to exclusively use the proteins A, C, G, T but could also take any sequence
of strings provided that each string is divided by a white space.

Of course, the main intention of such a program is to compare sequences of DNA strands.
The actual instructions for this program includes a better explaination of the biological
problem as well as an example of how such a program can be used.

For our sake, the purpose of this project is to give us a way to view processing time and
data management, especially for big "real life" data such as those from the ecoli files.
We used valgrind to keep track of the memory usage.

### Features
The main structure used is the vector of column vectors as one of the structures the
instructions suggested. This acts as our vector that allocates memory according to
string length. The actual alignment is done through a dynamic programming solution,
which was actually sort of done in reverse. Much like the instructions suggests, this
program splits the problem into 3 possible "subproblems". In code, they're written
in these conditions:

    (i == static_cast<int>(matrix.size())-1) && (j == static_cast<int>(matrix[i].size())-1)
    i == static_cast<int>(matrix.size())-1
    j == static_cast<int>(matrix[i].size())-1

Translated, the conditions are:
    optimal alignment matches x[i] up with y[j]
    optimal alignment matches x[i] with gap
    optimal alignment matches y[j] with gap

Each of these conditions is then followed by a way to store the optimal distance, which is then
later used in the actual alignment function with their own set of conditions. This function then
returns the entire "chart" produced from the string alignment process.

### Issues
The biggest problem at first was just understanding what needed to be done in the assignment.
More specifically, I ended up just developing in an approach where I implemented functions I'm
familiar with implementing, but then spending way too much time thinking about an approach for
the optDistance() and alignment() functions. It did click later that I didn't have to worry too
much about the letters needing to be specifically DNA proteins. Although, there were also some
problems deciding how and what structures to use.

### Extra Credit


## Analysis

### Example
Do one additional test case by hand. It should be constructed in such a way that you know the correct  output before running your program on it, and it should be a "corner case" that helps check if your program handles all special situations correctly. 

Please list:
 - a copy of the test case input
    - "Johnny", "Test"
 - the expected test case output
    - 8
 - whether your program ran correctly on it or not
    - yes, both in the main and in the test file
 - optionally, any other remarks

### Specs
Your Computer
Memory: 8gb (8192MB RAM)
Processors: AMD Ryzen 5 2500u with Radeon Vega Mobile Gfx (8 CPUS), ~2.0GHz

### Runs
Fill in the table with the results of running your code on both your and your partner's computers.

| data file     | distance | time (seconds) | partner time |
|---------------|----------|----------------|--------------|
|ecoli2500.txt  |      118 |       0.392265 |              |
|ecoli5000.txt  |      160 |        1.51109 |              |
|ecoli10000.txt |      223 |        6.32321 |              |
|ecoli20000.txt |     3135 |        29.1126 |              |
|ecoli28284.txt |     8394 |        57.9324 |              |
|ecoli50000.txt |          |                |              |
|ecoli100000.txt|          |                |              |

Here is an example from another computer for some of the files.

| data file    | distance | time (s) |
|--------------|----------|----------|
|ecoli2500.txt |      118 |    0.171 |
|ecoli5000.txt |      160 |    0.529 |
|ecoli7000.txt |      194 |    0.990 |
|ecoli10000.txt|      223 |    1.972 |
|ecoli20000.txt|     3135 |    7.730 |

### Time
Assume the two strings are the same length (M = N).  By applying the doubling method to the data points that you obtained, estimate the running time of yoru program in seconds as a polynomial function of N, in the form a * N^b for some constants a and b.  Determine the largest input size your computer can handle given the amount of memory available.

Provide a brief justification/explanation of how you applied the doubling method, and if you data seems not to work, describe what went wrong and use the sample data instead.
 - a = N/b^2
 - b = N/a^2
 - largest N = 28284

### Memory
Assume the two strings are the same length (M = N).  Look at your code and determine how much memory it requires as a polynomial function of N, in the form a * N^b for some constants a and b.  Determine the largest input size your computer can handle given the amount of memory available.
 - a = 
 - b = 
 - largest N = 28284


## Pair Programming
If you worked with a partner, do you have any remarks on the pair programming method? E.g., how many times did you switch, what are the tradeoffs of driving vs. navigating, etc.?



## Acknowledgements
List all sources of help including the instructor or TAs, classmates, and web pages.

