// Copyright 2023 Leonard Nguyen
#include <iostream>
#include <string>
#include <fstream>

#include "EDistance.hpp"

#define BOOST_TEST_DYN_LINK
#define BOOST_TEST_MODULE Main
#include <boost/test/unit_test.hpp>

BOOST_AUTO_TEST_CASE(penaltyTest1) {
    BOOST_CHECK_EQUAL(EDistance::penalty('A', 'B'), 1);
    BOOST_CHECK_EQUAL(EDistance::penalty('B', 'A'), 1);
    BOOST_CHECK_EQUAL(EDistance::penalty('A', 'A'), 0);
}

BOOST_AUTO_TEST_CASE(min3Test1) {
    BOOST_CHECK_EQUAL(EDistance::min3(1, 2, 3), 1);
    BOOST_CHECK_EQUAL(EDistance::min3(0, 1, 2), 0);
    BOOST_CHECK_EQUAL(EDistance::min3(0, 0, 1), 0);
    BOOST_CHECK_EQUAL(EDistance::min3(1, 0, 0), 0);
    BOOST_CHECK_EQUAL(EDistance::min3(3, 2, 1), 1);
}

BOOST_AUTO_TEST_CASE(editDistanceTest1) {
    EDistance example10("AACAGTTACC", "TAAGGTCA");
    BOOST_CHECK_EQUAL(example10.optDistance(), 7);

    EDistance endgaps7("atattat", "tattata");
    BOOST_CHECK_EQUAL(endgaps7.optDistance(), 4);

    EDistance fli8("CAGCTACAA", "CAGACAA");
    BOOST_CHECK_EQUAL(fli8.optDistance(), 4);
}

BOOST_AUTO_TEST_CASE(editDistanceTest2) {       // tests with letters other than proteins
    EDistance amongus("amongus", "amongus");
    BOOST_CHECK_EQUAL(amongus.optDistance(), 0);

    EDistance amongusWithGap("amongus", "amongsus");
    BOOST_CHECK_EQUAL(amongusWithGap.optDistance(), 2);

    EDistance johnnyTest("Johnny", "Test");
    BOOST_CHECK_EQUAL(johnnyTest.optDistance(), 8);
}

/*
BOOST_AUTO_TEST_CASE(fileInputEditDistanceTest1) {
    std::string sequence1, sequence2;
    std::cin >> sequence1 >> sequence2;

    // 28284 took a while
    EDistance ecoli28284(sequence1, sequence2);
    BOOST_CHECK_EQUAL(ecoli28284.optDistance(), 118);
}
*/
