// Copyright 2023 Leonard Nguyen
#include <SFML/System.hpp>

#include "EDistance.hpp"

int main() {
    sf::Clock clock;
    std::string sequence1, sequence2;
    std::cin >> sequence1 >> sequence2;

    EDistance editDistance(sequence1, sequence2);

    std::cout << "Edit distance = " << editDistance.optDistance() << std::endl;
    std::cout << editDistance.alignment() << std::endl;

    sf::Time t = clock.getElapsedTime();
    std::cout << "Execution time is " << t.asSeconds() << " seconds " << std::endl;
}
