// Copyright 2023 Leonard Nguyen
#include <iostream>
#include <string>
#include <fstream>

#include "Universe.hpp"

#define BOOST_TEST_DYN_LINK
#define BOOST_TEST_MODULE Main
#include <boost/test/unit_test.hpp>


BOOST_AUTO_TEST_CASE(universe1BodyTest) {
    std::ifstream fin("./src/1body.txt");
    Universe oneBodyUniverse;
    fin >> oneBodyUniverse;
    BOOST_CHECK_EQUAL(oneBodyUniverse.getN(), 1);
    BOOST_CHECK_EQUAL(oneBodyUniverse.getR(), 100);
    BOOST_CHECK_EQUAL(oneBodyUniverse.getBody(0)->getPosX(), 10);
    BOOST_CHECK_EQUAL(oneBodyUniverse.getBody(0)->getPosY(), 20);
    BOOST_CHECK_EQUAL(oneBodyUniverse.getBody(0)->getVelX(), 2);
    BOOST_CHECK_EQUAL(oneBodyUniverse.getBody(0)->getVelY(), 1);
    BOOST_CHECK_EQUAL(oneBodyUniverse.getBody(0)->getMass(), 1e20);
    BOOST_CHECK_EQUAL(oneBodyUniverse.getBody(0)->getBodyFileName(), "./src/earth.gif");
}

BOOST_AUTO_TEST_CASE(universe3BodyTest) {
    std::ifstream fin("./src/3body.txt");
    Universe threeBodyUniverse;
    fin >> threeBodyUniverse;
    BOOST_CHECK_EQUAL(threeBodyUniverse.getN(), 3);
    BOOST_CHECK_EQUAL(threeBodyUniverse.getR(), 1.25e11);
    BOOST_CHECK_EQUAL(threeBodyUniverse.getBody(0)->getPosX(), 0);
    BOOST_CHECK_EQUAL(threeBodyUniverse.getBody(0)->getPosY(), 0);
    BOOST_CHECK_EQUAL(threeBodyUniverse.getBody(0)->getVelX(), 0.05e04);
    BOOST_CHECK_EQUAL(threeBodyUniverse.getBody(0)->getVelY(), 0);
    BOOST_CHECK_EQUAL(threeBodyUniverse.getBody(0)->getMass(), 5.974e24);
    BOOST_CHECK_EQUAL(threeBodyUniverse.getBody(0)->getBodyFileName(), "./src/earth.gif");

    BOOST_CHECK_EQUAL(threeBodyUniverse.getBody(1)->getPosX(), 0);
    BOOST_CHECK_EQUAL(threeBodyUniverse.getBody(1)->getPosY(), 44999999488);
    BOOST_CHECK_EQUAL(threeBodyUniverse.getBody(1)->getVelX(), 3.00e04);
    BOOST_CHECK_EQUAL(threeBodyUniverse.getBody(1)->getVelY(), 0);
    BOOST_CHECK_EQUAL(threeBodyUniverse.getBody(1)->getMass(), 1.989e30);
    BOOST_CHECK_EQUAL(threeBodyUniverse.getBody(1)->getBodyFileName(), "./src/sun.gif");

    BOOST_CHECK_EQUAL(threeBodyUniverse.getBody(2)->getPosX(), 0);
    BOOST_CHECK_EQUAL(threeBodyUniverse.getBody(2)->getPosY(), -44999999488);
    BOOST_CHECK_EQUAL(threeBodyUniverse.getBody(2)->getVelX(), -3.00e04);
    BOOST_CHECK_EQUAL(threeBodyUniverse.getBody(2)->getVelY(), 0);
    BOOST_CHECK_EQUAL(threeBodyUniverse.getBody(2)->getMass(), 1.989e30);
    BOOST_CHECK_EQUAL(threeBodyUniverse.getBody(2)->getBodyFileName(), "./src/sun.gif");
}

BOOST_AUTO_TEST_CASE(universeSoapOperaTest) {
    std::ifstream fin("./src/soap-opera.txt");
    Universe soapOperaUniverse;
    fin >> soapOperaUniverse;
    BOOST_CHECK_EQUAL(soapOperaUniverse.getN(), 4);
    BOOST_CHECK_EQUAL(soapOperaUniverse.getR(), 3.00e11);
    BOOST_CHECK_EQUAL(soapOperaUniverse.getBody(0)->getPosX(), 0);
    BOOST_CHECK_EQUAL(soapOperaUniverse.getBody(0)->getPosY(), 115470000128);
    BOOST_CHECK_EQUAL(soapOperaUniverse.getBody(0)->getVelX(), -3.6524e4);
    BOOST_CHECK_EQUAL(soapOperaUniverse.getBody(0)->getVelY(), 0);
    BOOST_CHECK_EQUAL(soapOperaUniverse.getBody(0)->getMass(), 3.3e30);
    BOOST_CHECK_EQUAL(soapOperaUniverse.getBody(0)->getBodyFileName(), "./src/sun.gif");

    BOOST_CHECK_EQUAL(soapOperaUniverse.getBody(1)->getPosX(), 99999997952);
    BOOST_CHECK_EQUAL(soapOperaUniverse.getBody(1)->getPosY(), -57735000064);
    BOOST_CHECK_EQUAL(soapOperaUniverse.getBody(1)->getVelX(), 1.8262e4);
    BOOST_CHECK_EQUAL(soapOperaUniverse.getBody(1)->getVelY(), 3.1631e4);
    BOOST_CHECK_EQUAL(soapOperaUniverse.getBody(1)->getMass(), 3.3e30);
    BOOST_CHECK_EQUAL(soapOperaUniverse.getBody(1)->getBodyFileName(), "./src/mars.gif");

    BOOST_CHECK_EQUAL(soapOperaUniverse.getBody(2)->getPosX(), -99999997952);
    BOOST_CHECK_EQUAL(soapOperaUniverse.getBody(2)->getPosY(), -57735000064);
    BOOST_CHECK_EQUAL(soapOperaUniverse.getBody(2)->getVelX(), 1.8262e4);
    BOOST_CHECK_EQUAL(soapOperaUniverse.getBody(2)->getVelY(), -3.1631e4);
    BOOST_CHECK_EQUAL(soapOperaUniverse.getBody(2)->getMass(), 3.3e30);
    BOOST_CHECK_EQUAL(soapOperaUniverse.getBody(2)->getBodyFileName(), "./src/venus.gif");

    BOOST_CHECK_EQUAL(soapOperaUniverse.getBody(3)->getPosX(), -249999998976);
    BOOST_CHECK_EQUAL(soapOperaUniverse.getBody(3)->getPosY(), 0);
    BOOST_CHECK_EQUAL(soapOperaUniverse.getBody(3)->getVelX(), 0);
    BOOST_CHECK_EQUAL(soapOperaUniverse.getBody(3)->getVelY(), 6e4);
    BOOST_CHECK_EQUAL(soapOperaUniverse.getBody(3)->getMass(), 3.302e20);
    BOOST_CHECK_EQUAL(soapOperaUniverse.getBody(3)->getBodyFileName(), "./src/mercury.gif");
}

BOOST_AUTO_TEST_CASE(universe1BodyPhysicsTest) {
    std::ifstream fin("./src/1body.txt");
    Universe oneBodyUniverse;
    double timeLimit = 60;
    double deltaT = 1;
    double time = 0;
    fin >> oneBodyUniverse;
    oneBodyUniverse.setTimeLimit(timeLimit);

    while (time < timeLimit) {
        oneBodyUniverse.step(deltaT);
        time += deltaT;
    }

    BOOST_CHECK_EQUAL(oneBodyUniverse.getN(), 1);
    BOOST_CHECK_EQUAL(oneBodyUniverse.getR(), 100);
    BOOST_CHECK_EQUAL(oneBodyUniverse.getBody(0)->getPosX(), 130);
    BOOST_CHECK_EQUAL(oneBodyUniverse.getBody(0)->getPosY(), 80);
    BOOST_CHECK_EQUAL(oneBodyUniverse.getBody(0)->getVelX(), 2);
    BOOST_CHECK_EQUAL(oneBodyUniverse.getBody(0)->getVelY(), 1);
    BOOST_CHECK_EQUAL(oneBodyUniverse.getBody(0)->getMass(), 1e20);
    BOOST_CHECK_EQUAL(oneBodyUniverse.getBody(0)->getBodyFileName(), "./src/earth.gif");
}

BOOST_AUTO_TEST_CASE(universe3BodyPhysicsTest) {
    std::ifstream fin("./src/3body.txt");
    Universe threeBodyUniverse;
    double timeLimit = 157788000;
    double deltaT = 25000;
    double time = 0;
    fin >> threeBodyUniverse;
    threeBodyUniverse.setTimeLimit(timeLimit);

    while (time < timeLimit) {
        threeBodyUniverse.step(deltaT);
        time += deltaT;
    }
    BOOST_CHECK_EQUAL(threeBodyUniverse.getN(), 3);
    BOOST_CHECK_EQUAL(threeBodyUniverse.getR(), 1.25e11);
    BOOST_CHECK_CLOSE(threeBodyUniverse.getBody(0)->getPosX(), -1.28106e13, 1);    // -1.28106e+13
    BOOST_CHECK_CLOSE(threeBodyUniverse.getBody(0)->getPosY(), -2.78618e13, 1);    // -2.78618e+13
    BOOST_CHECK_CLOSE(threeBodyUniverse.getBody(0)->getVelX(), -167856, 1);        // -167856
    BOOST_CHECK_CLOSE(threeBodyUniverse.getBody(0)->getVelY(), -364999, 1);      // -364999
    BOOST_CHECK_EQUAL(threeBodyUniverse.getBody(0)->getMass(), 5.974e24);
    BOOST_CHECK_EQUAL(threeBodyUniverse.getBody(0)->getBodyFileName(), "./src/earth.gif");

    BOOST_CHECK_CLOSE(threeBodyUniverse.getBody(1)->getPosX(), 2.70375e12, 1);      // 2.70375e+12
    BOOST_CHECK_CLOSE(threeBodyUniverse.getBody(1)->getPosY(), 4.94576e12, 1);      // 4.94576e+12
    BOOST_CHECK_CLOSE(threeBodyUniverse.getBody(1)->getVelX(), 154792, 1);      // 154792
    BOOST_CHECK_CLOSE(threeBodyUniverse.getBody(1)->getVelY(), 284047.625, 1);         // 284048
    BOOST_CHECK_EQUAL(threeBodyUniverse.getBody(1)->getMass(), 1.989e30);
    BOOST_CHECK_EQUAL(threeBodyUniverse.getBody(1)->getBodyFileName(), "./src/sun.gif");

    BOOST_CHECK_CLOSE(threeBodyUniverse.getBody(2)->getPosX(), -1.42527e13, 1);    // -1.42527e+13
    BOOST_CHECK_CLOSE(threeBodyUniverse.getBody(2)->getPosY(), 1.54206e13, 1);     // 1.54206e+13
    BOOST_CHECK_CLOSE(threeBodyUniverse.getBody(2)->getVelX(), -819958, 1);         // -819958
    BOOST_CHECK_CLOSE(threeBodyUniverse.getBody(2)->getVelY(), 885668, 1);        // 885668
    BOOST_CHECK_EQUAL(threeBodyUniverse.getBody(2)->getMass(), 1.989e30);
    BOOST_CHECK_EQUAL(threeBodyUniverse.getBody(2)->getBodyFileName(), "./src/sun.gif");
}

BOOST_AUTO_TEST_CASE(planets0Steps) {
    std::ifstream fin("./src/planets.txt");
    Universe planetsUniverse;
    fin >> planetsUniverse;
    BOOST_CHECK_EQUAL(planetsUniverse.getN(), 5);
    BOOST_CHECK_EQUAL(planetsUniverse.getR(), 2.50e11);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(0)->getPosX(), 1.4960e+11, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(0)->getPosY(), 0, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(0)->getVelX(), 0, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(0)->getVelY(), 2.9800e+4, 1);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(0)->getMass(), 5.974e+24);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(0)->getBodyFileName(), "./src/earth.gif");

    BOOST_CHECK_CLOSE(planetsUniverse.getBody(1)->getPosX(), 2.2790e+11, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(1)->getPosY(), 0, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(1)->getVelX(), 0, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(1)->getVelY(), 2.4100e+4, 1);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(1)->getMass(), 6.4190e+23);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(1)->getBodyFileName(), "./src/mars.gif");

    BOOST_CHECK_CLOSE(planetsUniverse.getBody(2)->getPosX(), 5.7900e+10, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(2)->getPosY(), 0, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(2)->getVelX(), 0, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(2)->getVelY(), 4.7900e+4, 1);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(2)->getMass(), 3.3020e+23);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(2)->getBodyFileName(), "./src/mercury.gif");

    BOOST_CHECK_CLOSE(planetsUniverse.getBody(3)->getPosX(), 0, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(3)->getPosY(), 0, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(3)->getVelX(), 0, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(3)->getVelY(), 0, 1);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(3)->getMass(), 1.9890e+30);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(3)->getBodyFileName(), "./src/sun.gif");

    BOOST_CHECK_CLOSE(planetsUniverse.getBody(4)->getPosX(), 1.0820e+11, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(4)->getPosY(), 0, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(4)->getVelX(), 0, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(4)->getVelY(), 3.5000e+4, 1);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(4)->getMass(), 4.8690e+24);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(4)->getBodyFileName(), "./src/venus.gif");
}

BOOST_AUTO_TEST_CASE(planets1Step) {
    std::ifstream fin("./src/planets.txt");
    Universe planetsUniverse;
    fin >> planetsUniverse;
    planetsUniverse.step(25000);
    BOOST_CHECK_EQUAL(planetsUniverse.getN(), 5);
    BOOST_CHECK_EQUAL(planetsUniverse.getR(), 2.50e11);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(0)->getPosX(), 1.4960e+11, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(0)->getPosY(), 7.4500e+08, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(0)->getVelX(), -1.4820e+02, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(0)->getVelY(), 2.9800e+4, 1);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(0)->getMass(), 5.974e+24);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(0)->getBodyFileName(), "./src/earth.gif");

    BOOST_CHECK_CLOSE(planetsUniverse.getBody(1)->getPosX(), 2.2790e+11, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(1)->getPosY(), 6.0250e+08, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(1)->getVelX(), -6.3860e+01, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(1)->getVelY(), 2.4100e+4, 1);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(1)->getMass(), 6.4190e+23);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(1)->getBodyFileName(), "./src/mars.gif");

    BOOST_CHECK_CLOSE(planetsUniverse.getBody(2)->getPosX(), 5.7875e+10, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(2)->getPosY(), 1.1975e+09, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(2)->getVelX(), -9.8933e+02, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(2)->getVelY(), 4.7900e+04, 1);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(2)->getMass(), 3.3020e23);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(2)->getBodyFileName(), "./src/mercury.gif");

    BOOST_CHECK_CLOSE(planetsUniverse.getBody(3)->getPosX(), 3.3087e+01, 1);
    // BOOST_CHECK_CLOSE(planetsUniverse.getBody(3)->getPosY(), 0, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(3)->getVelX(), 1.3235e-03, 1);
    // BOOST_CHECK_CLOSE(planetsUniverse.getBody(3)->getVelY(), 0, 1);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(3)->getMass(), 1.9890e30);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(3)->getBodyFileName(), "./src/sun.gif");

    BOOST_CHECK_CLOSE(planetsUniverse.getBody(4)->getPosX(), 1.0819e+11, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(4)->getPosY(), 8.7500e+08, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(4)->getVelX(), -2.8329e+02, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(4)->getVelY(), 3.5000e+04, 1);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(4)->getMass(), 4.8690e24);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(4)->getBodyFileName(), "./src/venus.gif");
}

BOOST_AUTO_TEST_CASE(planets2Step) {
    std::ifstream fin("./src/planets.txt");
    Universe planetsUniverse;
    fin >> planetsUniverse;
    planetsUniverse.step(25000);
    planetsUniverse.step(25000);
    BOOST_CHECK_EQUAL(planetsUniverse.getN(), 5);
    BOOST_CHECK_EQUAL(planetsUniverse.getR(), 2.50e11);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(0)->getPosX(), 1.4959e+11, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(0)->getPosY(), 1.4900e+09, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(0)->getVelX(), -2.9640e+02, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(0)->getVelY(), 2.9799e+04, 1);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(0)->getMass(), 5.974e+24);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(0)->getBodyFileName(), "./src/earth.gif");

    BOOST_CHECK_CLOSE(planetsUniverse.getBody(1)->getPosX(), 2.2790e+11, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(1)->getPosY(), 1.2050e+09, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(1)->getVelX(), -1.2772e+02, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(1)->getVelY(), 2.4100e+04, 1);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(1)->getMass(), 6.4190e+23);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(1)->getBodyFileName(), "./src/mars.gif");

    BOOST_CHECK_CLOSE(planetsUniverse.getBody(2)->getPosX(), 5.7826e+10, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(2)->getPosY(), 2.3945e+09, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(2)->getVelX(), -1.9789e+03, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(2)->getVelY(), 4.7880e+04, 1);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(2)->getMass(), 3.3020e23);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(2)->getBodyFileName(), "./src/mercury.gif");

    BOOST_CHECK_CLOSE(planetsUniverse.getBody(3)->getPosX(), 9.9262e+01, 1);
    // BOOST_CHECK_CLOSE(planetsUniverse.getBody(3)->getPosY(), 2.8198e-01, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(3)->getVelX(), 2.6470e-03, 1);
    // BOOST_CHECK_CLOSE(planetsUniverse.getBody(3)->getVelY(), 1.1279e-05, 1);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(3)->getMass(), 1.9890e30);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(3)->getBodyFileName(), "./src/sun.gif");

    BOOST_CHECK_CLOSE(planetsUniverse.getBody(4)->getPosX(), 1.0818e+11, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(4)->getPosY(), 1.7499e+09, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(4)->getVelX(), -5.6660e+02, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(4)->getVelY(), 3.4998e+04, 1);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(4)->getMass(), 4.8690e24);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(4)->getBodyFileName(), "./src/venus.gif");
}

BOOST_AUTO_TEST_CASE(planets3Step) {
    std::ifstream fin("./src/planets.txt");
    Universe planetsUniverse;
    fin >> planetsUniverse;
    planetsUniverse.step(25000);
    planetsUniverse.step(25000);
    planetsUniverse.step(25000);
    BOOST_CHECK_EQUAL(planetsUniverse.getN(), 5);
    BOOST_CHECK_EQUAL(planetsUniverse.getR(), 2.50e11);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(0)->getPosX(), 1.4958e+11, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(0)->getPosY(), 2.2349e+09, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(0)->getVelX(), -4.4460e+02, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(0)->getVelY(), 2.9798e+04, 1);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(0)->getMass(), 5.974e+24);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(0)->getBodyFileName(), "./src/earth.gif");

    BOOST_CHECK_CLOSE(planetsUniverse.getBody(1)->getPosX(), 2.2789e+11, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(1)->getPosY(), 1.8075e+09, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(1)->getVelX(), -1.9158e+02, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(1)->getVelY(), 2.4099e+04, 1);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(1)->getMass(), 6.4190e+23);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(1)->getBodyFileName(), "./src/mars.gif");

    BOOST_CHECK_CLOSE(planetsUniverse.getBody(2)->getPosX(), 5.7752e+10, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(2)->getPosY(), 3.5905e+09, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(2)->getVelX(), -2.9682e+03, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(2)->getVelY(), 4.7839e+04, 1);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(2)->getMass(), 3.3020e23);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(2)->getBodyFileName(), "./src/mercury.gif");

    BOOST_CHECK_CLOSE(planetsUniverse.getBody(3)->getPosX(), 1.9852e+02, 1);
    // BOOST_CHECK_CLOSE(planetsUniverse.getBody(3)->getPosY(), 1.1280e+00, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(3)->getVelX(), 3.9705e-03, 1);
    // BOOST_CHECK_CLOSE(planetsUniverse.getBody(3)->getVelY(), 3.3841e-05, 1);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(3)->getMass(), 1.9890e30);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(3)->getBodyFileName(), "./src/sun.gif");

    BOOST_CHECK_CLOSE(planetsUniverse.getBody(4)->getPosX(), 1.0816e+11, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(4)->getPosY(), 2.6248e+09, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(4)->getVelX(), -8.4989e+02, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(4)->getVelY(), 3.4993e+04, 1);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(4)->getMass(), 4.8690e24);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(4)->getBodyFileName(), "./src/venus.gif");
}
/*
BOOST_AUTO_TEST_CASE(planets1Year) {
    std::ifstream fin("./src/planets.txt");
    Universe planetsUniverse;
    fin >> planetsUniverse;
    planetsUniverse.step(3.154e+7);
    BOOST_CHECK_EQUAL(planetsUniverse.getN(), 5);
    BOOST_CHECK_EQUAL(planetsUniverse.getR(), 2.50e11);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(0)->getPosX(), 1.4959e+11, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(0)->getPosY(), -1.6531e+09, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(0)->getVelX(), 3.2949e+02, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(0)->getVelY(), 2.9798e+04, 1);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(0)->getMass(), 5.974e+24);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(0)->getBodyFileName(), "./src/earth.gif");

    BOOST_CHECK_CLOSE(planetsUniverse.getBody(1)->getPosX(), -2.2153e+11, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(1)->getPosY(), -4.9263e+10, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(1)->getVelX(), 5.1805e+03, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(1)->getVelY(), -2.3640e+04, 1);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(1)->getMass(), 6.4190e+23);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(1)->getBodyFileName(), "./src/mars.gif");

    BOOST_CHECK_CLOSE(planetsUniverse.getBody(2)->getPosX(), 3.4771e+10, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(2)->getPosY(), 4.5752e+10, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(2)->getVelX(), -3.8269e+04, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(2)->getVelY(), 2.9415e+04, 1);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(2)->getMass(), 3.3020e23);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(2)->getBodyFileName(), "./src/mercury.gif");

    BOOST_CHECK_CLOSE(planetsUniverse.getBody(3)->getPosX(), 5.9426e+05, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(3)->getPosY(), 6.2357e+06, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(3)->getVelX(), -5.8569e-02, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(3)->getVelY(), 1.6285e-01, 1);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(3)->getMass(), 1.9890e30);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(3)->getBodyFileName(), "./src/sun.gif");

    BOOST_CHECK_CLOSE(planetsUniverse.getBody(4)->getPosX(), -7.3731e+10, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(4)->getPosY(), -7.9391e+10, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(4)->getVelX(), 2.5433e+04, 1);
    BOOST_CHECK_CLOSE(planetsUniverse.getBody(4)->getVelY(), -2.3973e+04, 1);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(4)->getMass(), 4.8690e24);
    BOOST_CHECK_EQUAL(planetsUniverse.getBody(4)->getBodyFileName(), "./src/venus.gif");
}
*/
