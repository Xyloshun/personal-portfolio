// Copyright 2023 Leonard Nguyen
#include "CelestialBody.hpp"

void CelestialBody::draw(sf::RenderTarget &target, sf::RenderStates states) const {
    sf::Texture celestialTexture;
    if (!celestialTexture.loadFromFile(_bodyFileName)) {
        return;
    } else {
        sf::Sprite celestialSprite;
        celestialSprite.setTexture(celestialTexture);
        double conversionFactor = (target.getSize().x / 2) / _universeRadius;
        float x = (_pos.x * conversionFactor);
        float y = -(_pos.y * conversionFactor);
        celestialSprite.setPosition(x + (target.getSize().x / 2), y + (target.getSize().y / 2));
        target.draw(celestialSprite);
    }
}

void CelestialBody::calculateVel(double forceX, double forceY, double seconds) {
    // calculate accel
    double accelX = forceX / _mass;
    double accelY = forceY / _mass;
    _vel.x = _vel.x + seconds * accelX;
    _vel.y = _vel.y + seconds * accelY;
}

void CelestialBody::calculatePos(double seconds) {
    _pos.x = _pos.x + seconds * _vel.x;
    _pos.y = _pos.y + seconds * _vel.y;
}

std::istream &operator>>(std::istream &in, CelestialBody &celestialBody) {
    in >> celestialBody._pos.x >> celestialBody._pos.y;
    in >> celestialBody._vel.x >> celestialBody._vel.y;
    in >> celestialBody._mass;
    in >> celestialBody._bodyFileName;
    celestialBody._bodyFileName = "./src/" + celestialBody._bodyFileName;
    return in;
}
std::ostream &operator<<(std::ostream &out, CelestialBody &celestialBody) {
    out << celestialBody.getPosX() << "  ";
    out << celestialBody.getPosY() << "  ";
    out << celestialBody.getVelX() << "  ";
    out << celestialBody.getVelY() << "  ";
    out << celestialBody.getMass() << "  ";
    out << celestialBody.getBodyFileName();
    return out;
}
