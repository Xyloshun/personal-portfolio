// Copyright 2023 Leonard Nguyen
#include <fstream>
#include <sstream>
#include <SFML/Audio.hpp>

#include "Universe.hpp"

int main(int argc, char *argv[]) {
    double timeLimit = atof(argv[1]);
    double deltaT = atof(argv[2]);
    double time = 0;

    sf::Font font;
    if (!font.loadFromFile("./src/NiseJSRF.ttf")) {} else {}
    sf::Text timeMessage;
    timeMessage.setFont(font);
    timeMessage.setCharacterSize(16);
    timeMessage.setFillColor(sf::Color::White);
    timeMessage.setStyle(sf::Text::Bold);

    /*
    sf::Music music;
    if (!music.openFromFile("./src/2001.wav")) {} else {}
    */

    Universe bigUniverse;
    std::cin >> bigUniverse;
    bigUniverse.setTimeLimit(timeLimit);

    const unsigned int windowSize = 512;
    sf::RenderWindow window(sf::VideoMode(windowSize, windowSize), "SFML works!");

    while (window.isOpen() && time < timeLimit) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window.close();
        }

        // music.play();
        bigUniverse.step(deltaT);
        std::stringstream timeString;
        timeString << "Time: " << time << " secs";
        timeMessage.setString(timeString.str());
        window.clear();
        window.draw(bigUniverse);
        window.draw(timeMessage);
        window.display();
        time += deltaT;
    }

    std::cout << bigUniverse << std::endl;

    return 0;
}
