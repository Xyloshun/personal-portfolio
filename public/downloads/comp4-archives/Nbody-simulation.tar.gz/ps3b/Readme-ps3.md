# PS3: N-Body Simulation

## Contact
Name: Leonard Nguyen
Section: 011 Summer
Time to Complete: 20 hours



## Changelog
    - Added and implemented physics to the N-Body simulation


## Description
The NBody Simulation is essentially a universe simulator. More specifically, the project
is to simulate the behavior of "particles" under the influence of gravitational forces
calculated by Isaac Newton. The purpose of this particular project is to introduce us to
a bigger program that has us create more drawable classes and make them abide to the laws
of physics.

This project is split into two parts, PS3a and PS3b. This part is PS3a.

PS3b is the physics and animation portion of this project. For this, we're tasked to
implement a "step" function, which represents a "step" in time of which the bodies
move. Essentially, we pass in a point in time (called deltaT), and calling the step
function once will display the position of the bodies in that moment in time. The
program also outputs the updated data after a loop of steps are completed. We also feed
the program a time limit as well to let it know when to stop. This is called the leapfrog finite difference approximation scheme.

### Features
As the instructions suggest, I created two drawable classes, Universe and CelestialBody.
Of course, both classes override the ostream and istream operators to handle the data
being fed in and out of them.

The data recorded for the CelestialBody are as follows:

    sf::Vector2f _pos; // position of the particle with x and y values
    sf::Vector2f _vel; // velocity of which the particle moves with x and y values
    double _mass; // mass of the particle
    std::string _bodyFileName; // file name to display the image

The data recorded for the Universe are as follows:

    int _n; // number of particles
    double _r; // radius of the universe
    std::shared_ptr<CelestialBody> _celestialVector; // pointer for a celestial body

For PS3b, the step function does all the provided calculations. These calculations are split
between velocity related and position related. Essentially, all the calculations for force,
acceleration, and new velocity were all done in the inner for each loop, whereas the final
positions to be drawn are set in the outer loop. Both for each loops iterate through the
same celestial smart pointer vector.

The main routine closes automatically when the time reaches the designated time limit.

### Memory
Smart pointers were required, so they were attempted in PS3a. After gaining a slightly better
understanding of smart pointers, I ended up making a vector of Celestial Body "pointers" in
order to properly manage celestial bodies without having to worry about deletion and
ownership.

## Extra Credit
Some text is drawn to display the "time" variable being updated. The number displayed
is the time being incremeted by deltaT.

### Issues
The y position and velocity values exceed 1% of the actual values.

## Acknowledgements
<https://www.geeksforgeeks.org/smart-pointers-cpp/>
<https://stackoverflow.com/questions/7132957/c-scientific-notation-format-number>
Dr. James Daly
