// Copyright 2023 Leonard Nguyen
#include "Universe.hpp"

void Universe::draw(sf::RenderTarget& target, sf::RenderStates states) const {
    sf::Texture backgroundTexture;
    if (!backgroundTexture.loadFromFile("./src/starfield.jpg")) {
        return;
    } else {
        sf::Sprite backgroundSprite;
        backgroundSprite.setTexture(backgroundTexture);
        backgroundSprite.setScale(target.getSize().x / backgroundTexture.getSize().x,
        target.getSize().y / backgroundTexture.getSize().y);
        target.draw(backgroundSprite);

        for (auto i : _celestialVector) {
            // 1 celestial body knows the calculation for the positions*
            // 2 separate universe and screen positions
            target.draw(*i);
        }
    }
}

void Universe::step(double seconds) {
    if (seconds > 0 && seconds <= _t) {      // 0 < seconds <= timeLimit
        for (auto &particle : _celestialVector) {
            for (auto &otherParticle : _celestialVector) {  // to compare two bodies
                if (particle != otherParticle) {
                    // calculate displacement
                    double deltaX = otherParticle->getPosX() - particle->getPosX();
                    double deltaY = otherParticle->getPosY() - particle->getPosY();
                    double r = sqrt((deltaX * deltaX) + (deltaY * deltaY));

                    // calculate force
                    double gForce = (G * otherParticle->getMass() * particle->getMass()) / (r * r);
                    double forceX = gForce * deltaX/r;
                    double forceY = gForce * deltaY/r;

                    // calculate new vel
                    particle->calculateVel(forceX, forceY, seconds);
                }
            }
            // calculate new pos
            particle->calculatePos(seconds);
        }
    } else { return; }
}

std::istream &operator>>(std::istream &in, Universe &universe) {
    in >> universe._n;
    in >> universe._r;
    for (int i = 0; i < universe._n; i++) {
        std::shared_ptr<CelestialBody> inputBody = std::make_shared<CelestialBody>(universe._r);
        in >> *inputBody;
        universe._celestialVector.push_back(inputBody);
    }
    return in;
}

std::ostream &operator<<(std::ostream &out, Universe &universe) {
    out << universe._n << std::endl;
    out << universe._r << std::endl;
    for (auto & i : universe._celestialVector) {
        out << *i << std::endl;
    }
    return out;
}
