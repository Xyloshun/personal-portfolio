// Copyright 2023 Leonard Nguyen
#pragma once

#include <memory>
#include <vector>
#include <cmath>
// #include <algorithm>

#include "CelestialBody.hpp"

class Universe: public sf::Drawable {
 public:
    const double G = 6.67e-11;

    Universe() {}
    friend std::istream &operator>>(std::istream &in, Universe &universe);
    friend std::ostream &operator<<(std::ostream &out, Universe &universe);

    int getN() {return _n;}         // getter for particle count(planets)
    double getR() {return _r;}      // getter for radius
    std::shared_ptr<CelestialBody> getBody(int index) { return _celestialVector.at(index); }

    void setTimeLimit(double t) { _t = t; }
    void step(double seconds);

 private:
    int _n;       // number of particles
    double _r;    // radius of the universe
    double _t;    // time limit of steps
    virtual void draw(sf::RenderTarget &target, sf::RenderStates states) const;

    std::vector<std::shared_ptr <CelestialBody>> _celestialVector;
};
