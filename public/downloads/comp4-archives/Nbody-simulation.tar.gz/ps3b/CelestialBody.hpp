// Copyright 2023 Leonard Nguyen
#pragma once

#include <iostream>
#include <string>
#include <SFML/Graphics.hpp>

class CelestialBody: public sf::Drawable {
 public:
    CelestialBody() {}
    explicit CelestialBody(double r): _universeRadius(r) {}
    friend std::istream &operator>>(std::istream &in, CelestialBody &celestialBody);

    double getPosX() const {return _pos.x;}
    double getPosY() const {return _pos.y;}
    double getVelX() const {return _vel.x;}
    double getVelY() const {return _vel.y;}
    double getMass() const {return _mass;}
    std::string getBodyFileName() const {return _bodyFileName;}

    void setPosX(double newX) {_pos.x = newX;}
    void setPosY(double newY) {_pos.y = newY;}
    void setVelX(double newX) {_vel.x = newX;}
    void setVelY(double newY) {_vel.y = newY;}

    void calculateVel(double forceX, double forceY, double seconds);
    void calculatePos(double seconds);

 private:
    virtual void draw(sf::RenderTarget& target, sf::RenderStates states) const;
    sf::Vector2f _pos;
    sf::Vector2f _vel;
    double _mass;
    std::string _bodyFileName;
    double _universeRadius;
    // sf::Vector2f _netForce;
};

std::ostream &operator<<(std::ostream &out, CelestialBody &celestialBody);
