#pragma once

#include <cmath>
#include <SFML/Graphics.hpp>

class PTree: public sf::Drawable {
public:
    PTree(double l, int n): _baseSquare(sf::Vector2f(0, 0), sf::Vector2f(l, l)), _n(n) {}

private:
    virtual void draw(sf::RenderTarget& target, sf::RenderStates states) const;
    sf::FloatRect _baseSquare;
    int _n;
};

void pTree(sf::RenderTarget &target, const int depth, const sf::RectangleShape &root);