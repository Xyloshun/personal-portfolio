#include "PTree.hpp"

void PTree::draw(sf::RenderTarget &target, sf::RenderStates states) const {
    sf::RectangleShape square{{_baseSquare.width, _baseSquare.width}};
    square.setPosition(target.getSize().x / 2.f, target.getSize().y - _baseSquare.width / 2.f);
    square.setOrigin(_baseSquare.width/2, _baseSquare.height/2);
    square.setFillColor(sf::Color(rand(), rand(), rand()));
    pTree(target, _n, square);
}

void pTree(sf::RenderTarget &target, const int depth, const sf::RectangleShape &root) {
    static const float soh = sqrt(2)/2;
    static const float cah = sqrt(2)/2;
    if (depth <= 0)
        return;
        
    target.draw(root);
    sf::Vector2f parentSize = root.getSize();
    sf::Transform parentTransform = root.getTransform();

    // left side
    sf::RectangleShape leftBranch = root;
    leftBranch.setFillColor(sf::Color(rand(), rand(), rand()));
    leftBranch.setSize(parentSize*cah);
    leftBranch.setOrigin(0, leftBranch.getSize().y);
    leftBranch.setPosition(parentTransform.transformPoint({0,0}));
    leftBranch.rotate(-45);
    pTree(target, depth-1, leftBranch);

    // right side
    sf::RectangleShape rightBranch = root;
    rightBranch.setFillColor(sf::Color(rand(), rand(), rand()));
    rightBranch.setSize(parentSize*soh);
    rightBranch.setOrigin(rightBranch.getSize());
    rightBranch.setPosition(parentTransform.transformPoint({parentSize.x, 0}));
    rightBranch.rotate(45);
    pTree(target, depth-1, rightBranch);
}