#include <iostream>

#include "PTree.hpp"

int main() {
    double length;
    int depth;
    std::cout << "Enter a length for the base square and a tree depth: ";
    std::cin >> length >> depth;
    const unsigned int windowSizeWidth = 6*length;
    const unsigned int windowSizeHeight = 4*length;
    PTree tree(length, depth);

    sf::RenderWindow window(sf::VideoMode(windowSizeWidth, windowSizeHeight), "SFML works!");

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window.close();
        }

        window.clear();
        // Draw Tree
        window.draw(tree);
        window.display();
    }

    return 0;
}