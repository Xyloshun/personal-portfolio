# PS2: Snowflake Fractal

## Contact
Name: Leonard Nguyen
Section: 011 Summer
Time to Complete: 11-12 hrs


## Description
This project is made to visually represent a fractal known as the Pythagoras Tree. To make
the fractal, the biggest point made was to be able to write out the key math portions that
fuel its generation. This being said, Pythagoras's theorem and some trig were necessary in
completeing this assignment. As of now, this program only represents the Pythagoras Tree for
when the triangles within them are 90 45 45 triangles.

### Features
As the instructions suggest, the program features a class that represents the Pythagoras tree.
The interesting thing about this particular class is it derives an SFML class called "Drawable".
In short, all it really means is that Drawable's "draw" function can be used to start off the
tree.

The program takes inputs for a single length of the initial square, and the depth of the
desired tree. However, rather than have a single length be stored, it's instead added to a
FloatRect for the draw function to use.

The draw function was taken from the brick used in our in class activity for developing Breakout.
The arguments from each function was then changed up to better draw out the initial square
required for the recursion to start. This included the FloatRect created from entering a
length for input. The code is as follows:

    sf::FloatRect _baseSquare; // found in the PTree class
    sf::RectangleShape square{{_baseSquare.width,_baseSquare.width}};
    square.setPosition(target.getSize().x / 2.f, target.getSize().y - _baseSquare.width / 2.f);
    square.setOrigin(_baseSquare.width/2,_baseSquare.height/2);
    pTree(target,_n, square);

Of course, the draw function by itself can't be recursive, therefore, it can only output the
initial square on its own. This is where the helper function pTree does all the math needed
to produce the full tree. To make it easier on myself, I decided to split the tree into two
halves, the length*cos(theta) side and the length*sin(theta) side (left and right respectively).
Each side handles similar, but different calculations for each function call that alters the
copied square preceding it. This was how the cosine side of the tree was calculated:

    sf::RectangleShape leftBranch = root;
    leftBranch.setSize(parentSize*cah);
    leftBranch.setOrigin(0, leftBranch.getSize().y);
    leftBranch.setPosition(parentTransform.transformPoint({0,0}));
    leftBranch.rotate(-45);
    pTree(target, depth-1, leftBranch);

parentSize and parentTransform are, of course, some parameters from the preceding square.
pTree is called again in this step until it moves on to the sine side (right side).

I also made two variables that hold "soh" and "cah" to represent the sides resulting
from "sohcahtoa" as part of the attempt for extra credit. The extra credit was to
have the program take an input for an angle, but that's not complete.

    static const float soh = sqrt(2)/2;
    static const float cah = sqrt(2)/2;

### Issues
The main challenge was mostly getting what we did for the Sierpinski/Snowflake activities and
putting it in the context of Drawable classes. It took me a lot longer than it should to just
understand how to utilize the draw function for this project and even longer to realize pTree
should be a helper function. Aside from this, the tree does generate only the symmetrical
tree, albeit pretty slowly.

This error still comes up whenever I try running SFML graphics. It takes a couple tries to
get the program running.:

Failed to get GLXFBConfig which corresponds to the window's visual
X Error of failed request:  BadValue (integer parameter out of range for operation)
  Major opcode of failed request:  149 (GLX)
  Minor opcode of failed request:  3 (X_GLXCreateContext)
  Value in failed request:  0x21
  Serial number of failed request:  32
  Current serial number in output stream:  32

### Extra Credit
I thought about doing something like utilizing the FibLFSR to randomize the colors for each
square, but decided on just using rand() for each rgb value of every setFillColor called.
Here's an example.

    square.setFillColor(sf::Color(rand(), rand(), rand()));

Although this didn't really produce a rainbow colored tree, it did make for a pretty neat
color changing tree.

## Acknowledgements
Dr. Daly's Sierpinski.cpp, Snowflake.cpp, and Brick.cpp

