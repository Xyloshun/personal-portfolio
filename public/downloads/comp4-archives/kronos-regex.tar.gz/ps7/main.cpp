// Copyright 2023 Leonard Nguyen

// http://www.boost.org/doc/libs/1_58_0/doc/html/date_time/gregorian.html
// http://www.boost.org/doc/libs/1_58_0/doc/html/date_time/posix_time.html

#include <iostream>
#include <string>
#include <fstream>
#include <regex>
#include "boost/date_time/gregorian/gregorian.hpp"
#include "boost/date_time/posix_time/posix_time.hpp"

// using boost::gregorian::date;
using boost::gregorian::date_duration;
// using boost::gregorian::date_period;
// using boost::gregorian::from_simple_string;

using boost::posix_time::ptime;
using boost::posix_time::time_facet;
using boost::posix_time::time_input_facet;
using boost::posix_time::time_duration;
using boost::posix_time::time_from_string;

int main(int argc, char *argv[]) {
    std::string inputFileName = argv[1];
    std::string outputFileName = inputFileName + ".rpt";

    std::ifstream fin(inputFileName);
    if (!fin.is_open()) {
        std::cout << "error: " << "Please enter a log file name in the local directory."
        << std::endl;
        return -1;
    } else {}
    std::ofstream fout(outputFileName);

    ptime startTimeStamp, endTimeStamp;

    std::regex startRegex("\\(log.c.166\\) server started");
    std::regex endRegex("(oejs.AbstractConnector:Started SelectChannelConnector)");
    std::string logLineContainer;

    int initiated = 0;
    int completed = 0;
    int linesScanned = 0;
    bool isBooting = false;
    std::stringstream finalOutput;

    // parse through file
    while (getline(fin, logLineContainer)) {
        linesScanned++;

        // find (log.c.166)
        if (regex_search(logLineContainer, startRegex)) {
            initiated++;
            std::stringstream dateStream(logLineContainer.substr(0, 19));
            // dateStream.imbue(std::locale(dateStream.getloc(),
            // new time_input_facet("%Y-%m-%d %H:%M:%S")));
            startTimeStamp = time_from_string(dateStream.str());

            if (isBooting == true) {    // check if boot is complete
                finalOutput << "**** Incomplete boot **** " << std::endl << std::endl;
            } else {
                isBooting = true;
            }

            finalOutput << "=== Device boot ===" << std::endl
            << linesScanned << "("<< inputFileName << "): "
            << dateStream.str() << " Boot Start" << std::endl;
        }

        // find oejs.AbstractConnector:Started SelectChannelConnector
        if (regex_search(logLineContainer, endRegex)) {
            completed++;
            std::stringstream dateStream(logLineContainer.substr(0, 19));
            // dateStream.imbue(std::locale(dateStream.getloc(),
            // new time_input_facet("%Y-%m-%d %H:%M:%S")));
            endTimeStamp = time_from_string(dateStream.str());
            isBooting = false;  // default false

            finalOutput << linesScanned << "(" << inputFileName << "): "
            << dateStream.str() << " Boot Complete" << std::endl;

            time_duration duration = endTimeStamp - startTimeStamp;
            finalOutput << "\tBoot Time: " << duration.total_milliseconds() << "ms"
            << std::endl << std::endl;
        }
    }

    // print EVERYTHING
    fout << "Device Boot Report" << std::endl << std::endl;
    fout << "InTouch log file: " << inputFileName << std::endl;
    fout << "Lines Scanned: " << linesScanned << std::endl << std::endl;
    fout << "Device boot count: initiated = " <<  initiated << ", completed: " << completed
    << std::endl << std::endl << std::endl;
    fout << finalOutput.str();

    return 0;
}
