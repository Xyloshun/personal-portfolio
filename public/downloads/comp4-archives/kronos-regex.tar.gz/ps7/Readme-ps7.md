# PS7: Kronos Log Parsing

## Contact
Name: Leonard Nguyen
Section: Summer 110
Time to Complete: 5-6 hours


## Description
This project is to use regular expressions, or "regex" to parse through log files. More
specifically, the log files we're tasked to parse are for the Kronos InTouch device.
Essentially, we're taking the logs found in the device and reviewing some of the information
the project instructions ask for. For this project, we were asked to output the device's
boot up timing by parsing through some log files, and storing the information in a report
file.

Since we're tracking the boot up timing, the instructions ask us to read the first logging
message: (log.c.166). This is when the booting starts.

The log entry that shows a boot up has been complete (successful) is shown here:
    oejs.AbstractConnector:Started SelectChannelConnector@0.0.0.0:9080

Boot ups can also fail, which don't have any log entries. When this is the case, we just
write into the report saying the boot up is "incomplete".

### Features
The main feature of this assignment is the regex search loop. The loop takes a getline
condition that stores each line of a log file until the end. However, there are two
checks in the loop, one to check for the start message, and the other for the complete
message. The interesting thing about these checks is the usage of regex_search functions.

The basic idea is if the regex_search finds (log.c.166) server started, it outputs the
information related to the start of the boot up.

If regex_search finds "oejs.AbstractConnector:Started SelectChannelConnector", then the
boot up is detected as "complete". The information on this is also outputted.

The output is stored in a stringstream, all to eventually be printed as a separate group
from the header created for extra credit.

    std::stringstream finalOutput;
    fout << finalOutput.str();

### Approach
Once reading the project instructions, I went to grab two files, stdin_boost.cpp, and
datetime.cpp. The stdin_boost.cpp is used to mess around with some regular expressions to write. The datetime.cpp is used to demonstrate how to use the boost posix time library to
store and output date and time.

I spent the majority of the time typing in some regular expressions in stdin_boost.cpp as
a tool to help learn how I could use them in the actual program.

I then took a look at some of the resources linked in the instructions and from the
datetime.cpp file to figure out how to use time, date, and regexs.

Once that was done, I just took the datetime.cpp file, and removed everything in main to make
it my main.cpp. From there, it was a matter of writing out the loop and formatting the
outputs to print the report as close to the device5_intouch.log_BOOT.rpt and the
device5_intouch.log_BOOTONLY.rpt files as possible.

### Regex
There're two regular expressions used in this project. One is the start, the other is the
complete message:

    std::regex startRegex("\\(log.c.166\\) server started");
    std::regex endRegex("(oejs.AbstractConnector:Started SelectChannelConnector)");

startRegex uses "\\" for both ends of the parentheses to indicate they're part of the string
we're looking for. Setting the regex "(log.c.166) server started" without "\\" groups the
log.c.166 into one string, completely ignoring the required parentheses.

This leads to how parentheses are handled in endRegex. Here, the parentheses are used to
group the entire string "oejs.AbstractConnector:Started SelectChannelConnector" as something
to be looked for, as opposed to it searching for parts of the string in the log file.

### Issues
I tried using faces to convert times to the desired results, but ended up using the full
string stream instead.

### Extra Credit
The program outputs a header like the device5_intouch.log_BOOT.rpt file.

## Acknowledgements
<https://cplusplus.com/reference/regex/regex_match/>
<https://cplusplus.com/reference/regex/ECMAScript/>
<https://www.boost.org/doc/libs/1_57_0/libs/regex/doc/html/boost_regex/syntax/perl_syntax.html>
<https://cplusplus.com/reference/regex/regex_search/>

<https://www.boost.org/doc/libs/1_57_0/doc/html/date_time.html>
<http://www.boost.org/doc/libs/1_58_0/doc/html/date_time/gregorian.html>
<http://www.boost.org/doc/libs/1_58_0/doc/html/date_time/posix_time.html>
<https://www.boost.org/doc/libs/1_57_0/doc/html/date_time/examples.html#date_time.examples.time_math>
<https://www.boost.org/doc/libs/1_57_0/doc/html/date_time/gregorian.html#date_time.gregorian.date_class>
