#pragma once

#include <iostream>
#include <string>
#include <vector>

class FibLFSR {
public:
    // Constructor to create LFSR with the given initial seed
    FibLFSR(std::string seed): _seed(seed) {}
    // Simulate one step and return the new bit as 0 or 1
    int step();
    // Simulate k steps and return a k-bit integer
    int generate(int k);
    // get seed
    std::string getSeed() const { return _seed; }
    // destructor
    ~FibLFSR() { delete [] _tap; _tap = NULL; }

private:
    // Any fields that you need
    int _n;
    std::string _seed;
    int *_tap = new int(_n); // taps between pos 15, 13, 12, and 10
};
std::ostream &operator<<(std::ostream &out, const FibLFSR &lfsr);