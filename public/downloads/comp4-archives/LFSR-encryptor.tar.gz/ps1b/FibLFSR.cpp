#include "FibLFSR.hpp"

int FibLFSR::step() {
    // initialize output and first 2 taps
    int remainingBit = 0;
    _tap[0] = _seed.at(0) - '0'; // pos 15
    _tap[1] = _seed.at(2) - '0'; // pos 13

    /***********************************************************
    // read and perform XORs
    for (size_t i = 0; i < _seed.size(); i++) {
        if ((_tap[0] == 1 && _tap[1] == 1) || (_tap[0] == 0 && _tap[1] == 0)) {
            remainingBit = 0;
        } else remainingBit = 1;
    }
    ************************************************************/

    // 15 xor 13
    if ((_tap[0] == 1 && _tap[1] == 1) || (_tap[0] == 0 && _tap[1] == 0)) {
        remainingBit = 0;
    } else remainingBit = 1;

    // set tap position and previous result xor 12
    _tap[2] = _seed.at(3) - '0'; // pos 12
    if ((remainingBit == 1 && _tap[2] == 1) || (remainingBit == 0 && _tap[2] == 0)) {
        remainingBit = 0;
    } else remainingBit = 1;

    // set tap position to 10 and previous result xor 10
    _tap[3] = _seed.at(5) - '0'; // pos 10
    if ((remainingBit == 1 && _tap[3] == 1) || (remainingBit == 0 && _tap[3] == 0)) {
        remainingBit = 0;
    } else remainingBit = 1;

    _seed.erase(0, 1);
    _seed.push_back(remainingBit + '0');

    return remainingBit;
}

int FibLFSR::generate(int k) {
    int result = 0;
    for (int i = 0; i < k; i++) {
        result = result * 2 + step();
    }
    return result;
}

std::ostream &operator<<(std::ostream &out, const FibLFSR &lfsr) {
    out << lfsr.getSeed();
    return out;
}