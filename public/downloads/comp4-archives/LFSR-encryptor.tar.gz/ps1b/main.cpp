#include <iostream>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>

#include "PhotoMagic.hpp"

int main() {
    // read three arguments from command line: source image file name, output image file name, and FibLFSR seed
    std::string sourceImageFileName;
    std::string outputImageFileName;
    std::string inputSeed;
    std::cout << "% PhotoMagic ";
    std::cin >> sourceImageFileName >> outputImageFileName >> inputSeed;

    /*****************************************************************
    std::cout << "Enter the name of your image file: " << std::endl;
    std::cin >> sourceImageFileName;
    std::cout << "Enter a name for your new image file:  " << std::endl;
    std::cin >> outputImageFileName;
    std::cout << "Enter a seed (in bits): " << std::endl;
    std::cin >> inputSeed;
    ******************************************************************/

    // set up the lfsr, sprite to display the image, and render the windows
    FibLFSR inputLFSR(inputSeed);
    sf::Image inputImage;
    if (!inputImage.loadFromFile(sourceImageFileName))
        return -1;
    sf::Image decryptedImage;
    if (!decryptedImage.loadFromFile(sourceImageFileName))
        return -1;

    sf::Vector2u size = inputImage.getSize();
    sf::RenderWindow afterWindow(sf::VideoMode(size.x, size.y), "After");
    sf::RenderWindow beforeWindow(sf::VideoMode(size.x, size.y), "Before");

    sf::Texture decryptedTexture;
    decryptedTexture.loadFromImage(decryptedImage);

    sf::Sprite decryptedSprite;
    decryptedSprite.setTexture(decryptedTexture);

    // encrypt the image with the FibLFSR transform function
    transform(inputImage, &inputLFSR);

    sf::Texture inputTexture;
    inputTexture.loadFromImage(inputImage);

    sf::Sprite inputSprite;
    inputSprite.setTexture(inputTexture);

    while (afterWindow.isOpen() && beforeWindow.isOpen()) {
        sf::Event event;
        while (afterWindow.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                afterWindow.close();
        }

        while (beforeWindow.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                beforeWindow.close();
        }

        afterWindow.clear(sf::Color::White);
        afterWindow.draw(inputSprite);
        afterWindow.display();

        beforeWindow.clear(sf::Color::White);
        beforeWindow.draw(decryptedSprite);
        beforeWindow.display();
    }

    // fredm: saving a PNG segfaults for me, though it does properly
    //   write the file
    if (!inputImage.saveToFile(outputImageFileName))
        return -1;

    return 0;
}