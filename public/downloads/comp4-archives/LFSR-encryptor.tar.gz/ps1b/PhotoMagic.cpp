#include "PhotoMagic.hpp"

void transform(sf::Image &image, FibLFSR *lfsr) {
    int width = image.getSize().x;
    int height = image.getSize().y;
    for (int x = 0; x < width; x++) {
		for (int y = 0; y < height; y++) {
            // p is a pixelimage.getPixel(x, y);
            sf::Color p = image.getPixel(x, y);
            p.r = p.r ^ lfsr->generate(70); // red
            p.g = p.g ^ lfsr->generate(50); // green
            p.b = p.b ^ lfsr->generate(30); // blue
            image.setPixel(x, y, p);
		}
	}
}