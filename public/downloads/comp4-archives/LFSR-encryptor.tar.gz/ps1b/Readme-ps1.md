# PS1: LFSR / PhotoMagic

## Contact
Name: Leonard Nguyen

Section: 011 Summer

Time to Complete: 5-6hrs


## Description
This project is split into two parts, PS1a and PS1b. In summary, the
entirety of the project is an image encryptor and decryptor. The encryption
is done by shifting each pixel of an image so that the image becomes unrecognizable.
Of course, the decryption restores the image to its former state after encryption.

This project is PS1b, using the previously made LFSR to transform pixels of an image.
As stated, the transform function uses such a structure to alter each individual pixel
in a pseudo-random method. This is mostly dependant on the seed. If an encrypted image
is run through the same seed it was initally encrypted in, it should return the original
image.

### Features
We were given two blocks of code, one is the "transform" function and the other is the
"pixels.cpp" file. With this being the case, the features specifically created for PS1b
are in two files, one is "main.cpp" and the other is "PhotoMagic.cpp". The "main.cpp"
holds the starter code from "pixels.cpp" and "PhotoMagic.cpp" holds the definition
for a transform function.

The "main.cpp" initiallizes two sprites and two windows to display them. One holds the
"before" image, the image before the transformation, and the other holds the "after" image,
the image after the transformation.

The "PhotoMagic.cpp" contains the defined transformation function. Fortunately, the basic
idea for how to iterate through each pixel is given by this nested for loop from "pixels.cpp":

    // create photographic negative image of upper-left 200 px square
	for (int x = 0; x<200; x++) {
		for (int y = 0; y< 200; y++) {
			p = image.getPixel(x, y);
			p.r = 255 - p.r;
			p.g = 255 - p.g;
			p.b = 255 - p.b;
			image.setPixel(x, y, p);
		}
	}

Of course, this bit of code was updated so that it covers an image's entire size and that it
uses the LFSR generate function to modify the pixel colors. This is the updated nested for loop:

    for (int x = 0; x < width; x++) {
		for (int y = 0; y < height; y++) {
            // p is a pixelimage.getPixel(x, y);
            sf::Color p = image.getPixel(x, y);
            p.r = p.r ^ lfsr->generate(70); // red
            p.g = p.g ^ lfsr->generate(50); // green
            p.b = p.b ^ lfsr->generate(30); // blue
            image.setPixel(x, y, p);
		}
	}

Width and Height are variables defined by the image's size. The arguements in generate were
just arbitrary numbers I decided on using. The operator used is the bitwise XOR to fit what
an LFSR does for steps.

### Issues
Haven't made any changes to the FibLFSR. Works for the cat.jpg and whitemamba.png images.
The program also doesn't run SFML part sometimes, returning this error here:

***********************************************************************
Failed to get GLXFBConfig which corresponds to the window's visual
X Error of failed request:  BadValue (integer parameter out of range for operation)
  Major opcode of failed request:  149 (GLX)
  Minor opcode of failed request:  3 (X_GLXCreateContext)
  Value in failed request:  0x21
  Serial number of failed request:  32
  Current serial number in output stream:  32
***********************************************************************

It takes a couple tries to get the windows to open, but when they do, the encryption/decryption
should work.

### Tests
There wasn't any boost tests I could think of doing that wasn't just adding more tests
for the LFSR, however I decided on adding an extra image to be sure the program works
for different file types and sizes.

The testing was mostly just first running the program a couple times to get the two windows
to behave the way I want it to, then running the program some more to see how the sprites
behave with the transform function.

## Acknowledgements
https://en.wikipedia.org/wiki/Linear-feedback_shift_register

